import{j as e}from"./vendor-web3-CU4tlwXS.js";import"./vendor-react-BB8kI09H.js";const l=({label:t,tooltip:n,variant:o="success"})=>{const s={success:"bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",warning:"bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",info:"bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300"};return e.jsxs("div",{className:"relative inline-block group",children:[e.jsx("span",{className:`text-xs px-2 py-1 rounded-full cursor-help select-none ${s[o]}`,children:t}),e.jsx("div",{className:`
                    pointer-events-none
                    absolute z-50
                    top-full mt-2 left-1/2 -translate-x-1/2
                    w-56
                    rounded-lg
                    bg-slate-900 text-white text-xs
                    px-3 py-2
                    opacity-0 group-hover:opacity-100
                    transition-opacity
                    shadow-xl
                `,children:n})]})};export{l as B};
